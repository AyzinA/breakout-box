#!/system/bin/sh

# OpenVPN tunnel interface created by OpenVPN Connect
VPN="tun0"

# OpenVPN subnet
VPN_NET="10.8.0.0/24"

# Custom routing tables
VPN_TABLE="100"
WAN_TABLE="101"

# How often to check for VPN/WAN changes
CHECK_INTERVAL="10"

# Classic ADB TCP port
ADB_PORT="5555"

# iptables binary
IPT="$(command -v iptables)"

# Last known state
LAST_WAN=""
LAST_GW=""
LAST_TUN_INDEX=""
LAST_TUN_ADDR=""


# Detect active internet interface
get_wan() {
  ip route get 8.8.8.8 | awk '
    {
      for(i=1;i<=NF;i++) {
        if($i=="dev" && $(i+1)!~ /^tun/) {
          print $(i+1)
          exit
        }
      }
    }'
}


# Detect active gateway, mostly needed for Wi-Fi
get_gateway() {
  ip route get 8.8.8.8 | awk '
    {
      for(i=1;i<=NF;i++) {
        if($i=="via") {
          print $(i+1)
          exit
        }
      }
    }'
}


# Guess Wi-Fi gateway when Android does not show it clearly
guess_wifi_gateway() {
  WLAN_IP="$(ip -4 addr show wlan0 | awk '/inet / {print $2}' | cut -d/ -f1)"
  [ -n "$WLAN_IP" ] && echo "$WLAN_IP" | awk -F. '{print $1"."$2"."$3".1"}'
}


# Get tunnel interface index
# If OpenVPN reconnects, tun0 may be recreated with a new index
get_tun_index() {
  ip -o link show "$VPN" | awk -F': ' '{print $1}'
}


# Get tunnel IPv4 address
# If OpenVPN reconnects, the address may disappear and return
get_tun_addr() {
  ip -4 addr show "$VPN" | awk '/inet / {print $2; exit}'
}


# Enable IPv4 forwarding on Android
enable_forwarding() {
  echo 1 > /proc/sys/net/ipv4/ip_forward

  for d in /proc/sys/net/ipv4/conf/*; do
    echo 1 > "$d/forwarding"
    echo 0 > "$d/rp_filter"
  done
}


# Remove old policy routing rules
clean_policy_rules() {
  ip rule del to "$VPN_NET" lookup "$VPN_TABLE" priority 9999
  ip rule del from "$VPN_NET" lookup "$WAN_TABLE" priority 10000
  ip rule del iif "$VPN" lookup "$WAN_TABLE" priority 10001

  ip route flush table "$VPN_TABLE"
  ip route flush table "$WAN_TABLE"
  ip route flush cache
}


# Remove old forwarding and NAT rules
clean_iptables_rules() {
  for OUT in "$1" "$LAST_WAN" wlan0 swlan0 rmnet_data0 rmnet_data1 rmnet_data2 rmnet_data3 rmnet0 rmnet1 rmnet2 rmnet3 rmnet4 ccmni0 ccmni1 wwan0 usb0 kernel link; do
    [ -z "$OUT" ] && continue

    while $IPT -D FORWARD -i "$VPN" -o "$OUT" -s "$VPN_NET" -j ACCEPT; do :; done

    while $IPT -D FORWARD -i "$OUT" -o "$VPN" -d "$VPN_NET" -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT; do :; done

    while $IPT -t nat -D POSTROUTING -s "$VPN_NET" -o "$OUT" -j MASQUERADE; do :; done

    while $IPT -t nat -D tetherctrl_nat_POSTROUTING -s "$VPN_NET" -o "$OUT" -j MASQUERADE; do :; done
  done
}


# Clear stale NAT sessions if conntrack exists
flush_conntrack() {
  if command -v conntrack >/dev/null; then
    conntrack -F
  fi
}


# Apply routing and NAT rules
apply_rules() {
  WAN="$1"
  GW="$2"

  # Do nothing if no WAN was detected
  [ -z "$WAN" ] && return 1

  enable_forwarding

  clean_policy_rules

  # Route traffic back to VPN clients through tun0
  ip rule add to "$VPN_NET" lookup "$VPN_TABLE" priority 9999
  ip route replace "$VPN_NET" dev "$VPN" table "$VPN_TABLE"

  # Route traffic coming from VPN clients through the real WAN
  ip rule add from "$VPN_NET" lookup "$WAN_TABLE" priority 10000
  ip rule add iif "$VPN" lookup "$WAN_TABLE" priority 10001

  # Set default route for VPN client traffic
  if [ -n "$GW" ]; then
    ip route replace default via "$GW" dev "$WAN" table "$WAN_TABLE"
  else
    ip route replace default dev "$WAN" table "$WAN_TABLE"
  fi

  ip route flush cache

  clean_iptables_rules "$WAN"

  # Allow VPN clients to go out through WAN
  $IPT -I FORWARD 1 -i "$VPN" -o "$WAN" -s "$VPN_NET" -j ACCEPT

  # Allow replies from WAN back to VPN clients
  $IPT -I FORWARD 2 -i "$WAN" -o "$VPN" -d "$VPN_NET" -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT

  # NAT VPN clients through the active WAN interface
  $IPT -t nat -I POSTROUTING 1 -s "$VPN_NET" -o "$WAN" -j MASQUERADE

  # Android tethering NAT chain, if it exists
  $IPT -t nat -I tetherctrl_nat_POSTROUTING 1 -s "$VPN_NET" -o "$WAN" -j MASQUERADE

  # Clear stale NAT state after VPN reconnect or WAN switch
  flush_conntrack

  LAST_WAN="$WAN"
  LAST_GW="$GW"
}


# Enable classic ADB TCP mode on port 5555
# This is not the same as Android Wireless Debugging UI
enable_adb_tcp() {
  setprop persist.adb.tcp.port "$ADB_PORT"
  setprop service.adb.tcp.port "$ADB_PORT"

  setprop ctl.restart adbd

  sleep 3

  stop adbd

  sleep 2

  start adbd
}


# Wait for Android boot/network services
sleep 20

# Enable classic ADB TCP once after boot
enable_adb_tcp


# Main monitor loop
while true; do

  # If OpenVPN tunnel is down, clean state and wait
  if [ ! -d "/sys/class/net/$VPN" ]; then
    clean_policy_rules

    LAST_WAN=""
    LAST_GW=""
    LAST_TUN_INDEX=""
    LAST_TUN_ADDR=""

    sleep "$CHECK_INTERVAL"
    continue
  fi

  # Detect current WAN and VPN state
  WAN="$(get_wan)"
  GW="$(get_gateway)"
  TUN_INDEX="$(get_tun_index)"
  TUN_ADDR="$(get_tun_addr)"

  # Android sometimes does not expose Wi-Fi gateway clearly
  if [ -z "$GW" ] && [ "$WAN" = "wlan0" ]; then
    GW="$(guess_wifi_gateway)"
  fi

  # Reapply rules when:
  # - Wi-Fi / 3G/4G/5G changes
  # - Gateway changes
  # - OpenVPN reconnects and tun0 is recreated
  # - tun0 IP changes
  if [ "$WAN" != "$LAST_WAN" ] || \
     [ "$GW" != "$LAST_GW" ] || \
     [ "$TUN_INDEX" != "$LAST_TUN_INDEX" ] || \
     [ "$TUN_ADDR" != "$LAST_TUN_ADDR" ]; then

    apply_rules "$WAN" "$GW"

    LAST_TUN_INDEX="$TUN_INDEX"
    LAST_TUN_ADDR="$TUN_ADDR"
  fi

  sleep "$CHECK_INTERVAL"
done
